-- =====================================================
-- ESQUEMA DE BASE DE DATOS PARA HABIBBI CAFÉ
-- Sistema de gestión para cafetería
-- =====================================================

-- Crear base de datos
CREATE DATABASE IF NOT EXISTS habibbi CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE habibbi;

-- =====================================================
-- TABLA DE USUARIOS
-- =====================================================
CREATE TABLE usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario VARCHAR(50) NOT NULL UNIQUE,
  contraseña VARCHAR(100) NOT NULL,
  rol ENUM('admin', 'vendedor') NOT NULL,
  activo BOOLEAN DEFAULT TRUE
);

-- =====================================================
-- TABLA DE CLIENTES
-- =====================================================
CREATE TABLE clientes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  correo VARCHAR(100),
  telefono VARCHAR(20),
  fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================
-- TABLA DE INSUMOS
-- =====================================================
CREATE TABLE insumos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  unidad VARCHAR(20),
  stock DECIMAL(10,2) DEFAULT 0,
  alerta_stock DECIMAL(10,2) DEFAULT 5
);

-- =====================================================
-- TABLA DE PRODUCTOS
-- =====================================================
CREATE TABLE productos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  precio DECIMAL(10,2) NOT NULL,
  categoria VARCHAR(50),
  stock INT DEFAULT 0
);

-- =====================================================
-- TABLA DE RECETAS
-- =====================================================
CREATE TABLE recetas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  producto_id INT,
  FOREIGN KEY (producto_id) REFERENCES productos(id) ON DELETE CASCADE
);

-- =====================================================
-- DETALLE DE RECETA (INSUMOS POR PRODUCTO)
-- =====================================================
CREATE TABLE detalle_receta (
  id INT AUTO_INCREMENT PRIMARY KEY,
  receta_id INT,
  insumo_id INT,
  cantidad DECIMAL(10,2),
  FOREIGN KEY (receta_id) REFERENCES recetas(id) ON DELETE CASCADE,
  FOREIGN KEY (insumo_id) REFERENCES insumos(id)
);

-- =====================================================
-- TABLA DE VENTAS
-- =====================================================
CREATE TABLE ventas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT,
  cliente_id INT,
  fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
  metodo_pago ENUM('efectivo', 'tarjeta'),
  total DECIMAL(10,2),
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
  FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);

-- =====================================================
-- DETALLE DE VENTA
-- =====================================================
CREATE TABLE detalle_venta (
  id INT AUTO_INCREMENT PRIMARY KEY,
  venta_id INT,
  producto_id INT,
  cantidad INT,
  subtotal DECIMAL(10,2),
  FOREIGN KEY (venta_id) REFERENCES ventas(id) ON DELETE CASCADE,
  FOREIGN KEY (producto_id) REFERENCES productos(id)
);

-- =====================================================
-- TABLA DE CAJA
-- =====================================================
CREATE TABLE caja (
  id INT AUTO_INCREMENT PRIMARY KEY,
  fecha DATE,
  apertura DECIMAL(10,2),
  cierre DECIMAL(10,2),
  diferencia DECIMAL(10,2),
  observaciones TEXT
);

-- =====================================================
-- MOVIMIENTOS DE CAJA
-- =====================================================
CREATE TABLE movimientos_caja (
  id INT AUTO_INCREMENT PRIMARY KEY,
  caja_id INT,
  tipo ENUM('ingreso', 'egreso'),
  monto DECIMAL(10,2),
  descripcion VARCHAR(100),
  hora DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (caja_id) REFERENCES caja(id) ON DELETE CASCADE
);

-- =====================================================
-- DATOS INICIALES
-- =====================================================

-- Insertar usuarios iniciales
INSERT INTO usuarios (usuario, contraseña, rol) VALUES
('admin', 'admin123', 'admin'),
('vendedor', 'vendedor123', 'vendedor');

-- Insertar clientes de ejemplo
INSERT INTO clientes (nombre, correo, telefono) VALUES
('Juan Pérez', 'juan.perez@email.com', '+56912345678'),
('María González', 'maria.gonzalez@email.com', '+56987654321'),
('Carlos López', 'carlos.lopez@email.com', '+56911223344');

-- Insertar insumos iniciales
INSERT INTO insumos (nombre, unidad, stock, alerta_stock) VALUES
('Café en Grano', 'kg', 15.00, 5.00),
('Leche Entera', 'litros', 8.00, 10.00),
('Azúcar', 'kg', 2.00, 5.00);

-- Insertar productos iniciales
INSERT INTO productos (nombre, precio, categoria, stock) VALUES
('Café Americano', 2500.00, 'Bebidas Calientes', 50),
('Cappuccino', 3500.00, 'Bebidas Calientes', 30),
('Croissant', 1800.00, 'Panadería', 25);

-- Insertar recetas de ejemplo
INSERT INTO recetas (producto_id) VALUES
(1), -- Café Americano
(2); -- Cappuccino

-- Insertar detalles de recetas
INSERT INTO detalle_receta (receta_id, insumo_id, cantidad) VALUES
(1, 1, 0.02), -- Café Americano: 0.02kg de café
(2, 1, 0.02), -- Cappuccino: 0.02kg de café
(2, 2, 0.15); -- Cappuccino: 0.15 litros de leche

-- =====================================================
-- ÍNDICES PARA OPTIMIZACIÓN
-- =====================================================
CREATE INDEX idx_ventas_fecha ON ventas(fecha);
CREATE INDEX idx_ventas_usuario ON ventas(usuario_id);
CREATE INDEX idx_ventas_cliente ON ventas(cliente_id);
CREATE INDEX idx_detalle_venta_venta ON detalle_venta(venta_id);
CREATE INDEX idx_detalle_venta_producto ON detalle_venta(producto_id);
CREATE INDEX idx_movimientos_caja_caja ON movimientos_caja(caja_id);
CREATE INDEX idx_movimientos_caja_hora ON movimientos_caja(hora);